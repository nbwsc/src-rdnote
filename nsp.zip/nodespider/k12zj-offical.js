var request = require('request');
var http = require("http"); //http request
var iconv = require('iconv-lite'); //gbk convert*


setInterval(function () {    
    var dd = new Date()
    var d = dd.getHours();
    tmstmp = dd.getHours().toString() + ':' +dd.getMinutes().toString() + ':' + dd.getSeconds().toString()

    if (d<24 && d >7) {
        // console.log("*******************",tmstmp,"**************************");
        spiderZjk12Offical();
    }
}, 15 * 1000)



function requestUrl(url,handleBody) {

    http.get(url, function(res) {
        var arrBuf = [];
        var bufLength = 0;
        res.on("data", function(chunk) {
            arrBuf.push(chunk);
            bufLength += chunk.length;
          })
          .on("end", function() { //response callback
            // arrBuf是个存byte数据块的数组，byte数据块可以转为字符串，数组可不行
            // bufferhelper也就是替你计算了bufLength而已 
            var chunkAll = Buffer.concat(arrBuf, bufLength);
            var content = iconv.decode(chunkAll, 'gb2312'); // utf-8 content
            // fs.writeFileSync('data',content)
            handleBody(content);
        });
    });
}


function spiderZjk12Offical(){

    var dd = new Date();
    var issue = [];

    var d = dd.getHours();

    if(d < 9 || d > 22 ) return;

    var kgtyear = dd.getYear().toString().slice(1, 3);
    var kgtMonth = dd.getMonth() +1;
    if(kgtMonth < 10){
        kgtMonth = '0' + kgtMonth;
    }
    var kgtDay = dd.getDate();
     if(kgtDay < 10){
        kgtDay = '0' + kgtDay;
    }
    var kgt = kgtyear + kgtMonth + kgtDay;

    issue[0] = ['001','002','003','004','005'];
    issue[1] = ['006','007','008','009','010'];
    issue[13] = ['078','079','080'];

    for(var i = 2; i <= 12; i++){
        issue[i] = ['0'+(6*i).toString(),'0'+(6*i+1).toString(),'0'+(6*i+2).toString(),'0'+(6*i+3).toString(),'0'+(6*i+4).toString(),'0'+(6*i+5).toString()];        
    }
    
    for(var j=0;j<issue[d-9].length;j++){
        var url = 'http://fcasp.zjol.com.cn/zjfc/12asp_gg_12_5.asp?qishu=' + kgt + issue[d-9][j];
        // console.log(url);
        requestUrl(url, function(body) {
            // console.log(body);
            if(body.indexOf("非常遗憾")>=0){
                return;
            }
            var exp = `px12line21`;
            var ars = body.split(exp);
            // console.log(ars);
            
            // var tmpqh = ars[0].split('</strong> ')[1].split(' <strong>')[0];
            var tmpqh = ars[0].split('第</strong> ')[1].split(' <strong>期')[0];
            var qh = tmpqh.slice(-2);
            var haf = ars[1].split("number");
            var kjs = [];
            for(var n=1;n<6;n++){
                kjs[n-1] = haf[n].split('<strong>')[1].split('</strong')[0];
            }
            // console.log(kjs)
            request('http://123.57.138.66:8108' + '/InsertKjInf?KGTime=' + kgt + '&Qh=' +qh + '&ServerIP=' + 'of' + dd.getHours() + dd.getMinutes() + dd.getSeconds() + '&Kj1=' +
                kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3] + '&Kj5=' + kjs[4], (err, resp, body) => {
                    if(body && body !== 'Insert Exit ')
                        console.log("8108",body,kjs, kgt, qh,tmstmp)
            })
        })
    }
}
