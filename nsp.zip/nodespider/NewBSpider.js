var request = require('request');
// var http = require("http"); //http request
// var cheerio = require('cheerio'); //xml parser*
// var iconv = require('iconv-lite'); //gbk convert*
var gCookie;


var logindata = JSON.stringify({
    "username": "admin",
    "password": "7c4a8d09ca3762af61e59520943dc26494f8941b"
});

loginForNew('http://123.57.212.33:8000/caipiao/web/login', logindata, function() {
    setInterval(function() {
        var d = new Date().getHours();
        if (d < 24 && d > 7) {
            // 吉林快3和11选5
            NewBSpiderOld88K3(8096, 1);
            // NewBSpiderydniuK3('http://www.ydniu.com/open/84.html', '吉林快3');
            // NewBSpiderdzzAllGetMore('http://www.dzzst.com/m/chart/jlk3/k3-001/lastData.html?pcode=20171231-100', '吉林快3');
            // NewBSpiderBcK3('http://server.baibaocp.com/web/kslist/lotid/10401/num/1','吉林快3');
            NewBSpiderOld8811x5(8098, 1);

            //北京11选5和快3
            NewBSpiderOld8811x5(8088, 1);
            NewBSpiderOld88K3(8095, 1);

            //黑龙江11选5
            NewBSpiderOld8811x5(8097, 1);
            // NewBSpiderHlj11x5Zhenghao();

            //宁夏快3
            NewBSpiderOld88K3(8121, 1);

            //河北快3和11选5
            // NewBSpiderBcK3('http://server.baibaocp.com/web/kslist/lotid/10403/num/1','河北快3');
            NewBSpiderOld88K3(8101, 1);
            NewBSpiderOld8811x5(8102, 1);
            // NewBSpiderMobHebK3Official("http://m.yzfcw.com/prize/list.php?lotteryType=HBP3",1);

            //天津快乐十分和11选5
            //NewBSpiderWebK10('http://kl10.icaile.com/tjkl10.php?op=dcjb&num=10', '天津快乐十分');
            // NewBSpiderBcK10('http://server.baibaocp.com/web/klsflist/lotid/10304/num/1', '天津快乐十分');
            NewBSpiderOld88k10(8084, 1);
            NewBSpiderOld8811x5(8083, 1);
            setTimeout(function() {
                //广东11选5
                NewBSpiderOld8811x5(8091, 1);
                NewBSpiderOld8811x5(8114, 1);

                //甘肃11选5和甘肃快3
                NewBSpiderOld8811x5(8094, 1);
                NewBSpiderOld88K3(8112, 1);
                // NewBSpiderydniuK3('http://www.ydniu.com/open/129.html', '甘肃快3');

                //低频彩

                // if((d >= 20 && d <= 22) || (d >= 8 && d <= 9)){
                //     NewBSpiderOfficePl5('http://www.lottery.gov.cn/historykj/history.jspx?_ltype=plw',1);
                //     NewBSpiderOfficeQxc('http://www.lottery.gov.cn/historykj/history.jspx?_ltype=qxc',1);
                //     NewSpiderMobWeb('http://m.dlt.icaile.com/kaijiang/2','大乐透');
                //     NewSpiderMobWeb('http://m.ssq.icaile.com/kaijiang/2','双色球');
                //     NewSpiderMobWeb('http://m.3d.icaile.com/kaijiang/2','3D');
                // }

                NewBSpiderOld8811x5(8131, 1)

                //陕西11选5\快乐十分
                NewBSpiderOld88k10(8105, 1);
                NewBSpiderOld8811x5(8104, 1);

                //内蒙体彩11选5和快3
                NewBSpiderOld8811x5(8092, 1);
                NewBSpiderOld88K3(8093, 1);

                //江苏快3、青海快3、湖北快3、江西快3、福建快3、安徽快3、贵州快3
                NewBSpiderOld88K3(8106, 1);
                NewBSpiderOld88K3(8126, 1);
            }, 5000)
            setTimeout(function() {
                NewBSpiderOld88K3(8128, 1);
                NewBSpiderOld88K3(8129, 1);
                NewBSpiderOld88K3(8117, 1);
                NewBSpiderOld88K3(8116, 1);
                NewBSpiderOld88K3(8122, 1);

                //云南快乐十分和云南11选5
                NewBSpiderOld88k10(8124, 1);
                NewBSpiderOld8811x5(8123, 1);

                //山西快乐十分
                NewBSpiderOld88k10(8110, 1);

                //广东快乐十分
                NewBSpiderOld88k10(8099, 1);

                //黑龙江快乐十分
                NewBSpiderOld88k10(8130, 1);

                //浙江福彩快乐彩
                NewBSpiderOld8811x5(8108, 1);

                //宁夏11选5
                NewBSpiderOld8811x5(8111, 1);

            })

            // NewSpiderBjoffical('PK10',1);
            // NewSpiderBjoffical('快3',1);

            // NewBSpiderdzzAllGetMore('http://www.dzzst.com/m/chart/hnytdj/ytdj-001/lastData.html?pcode=20171231-100', '泳坛夺金481');
        }
    }, 15 * 1000)
});

setInterval(function() {
    loginForNew('http://123.57.212.33:8000/caipiao/web/login', logindata);
}, 3600 * 1000)



// function requestUrl(url,handleBody) {

//     http.get(url, function(res) {
//         var arrBuf = [];
//         var bufLength = 0;
//         res.on("data", function(chunk) {
//             arrBuf.push(chunk);
//             bufLength += chunk.length;
//           })
//           .on("end", function() { //response callback
//             // arrBuf是个存byte数据块的数组，byte数据块可以转为字符串，数组可不行
//             // bufferhelper也就是替你计算了bufLength而已 
//             var chunkAll = Buffer.concat(arrBuf, bufLength);
//             var content = iconv.decode(chunkAll, 'gb2312'); // utf-8 content
//             // fs.writeFileSync('data',content)
//             handleBody(content);
//         });
//     });
// }



function loginForNew(theurl, thebody, callback) {
    var d = new Date();
    var options = {
        method: 'POST',
        url: theurl,
        headers: {
            'authorization': 'Basic YWRtaW46N2M0YThkMDljYTM3NjJhZjYxZTU5NTIwOTQzZGMyNjQ5NGY4OTQxYg==',
            // 'content-type': 'application/json',
            'cache-control': 'no-cache',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36'
        },
        body: thebody
    };
    // console.log(options)
    request(options, (error, response, body) => {
        // console.log(error, body);
        if (!error) {
            gCookie = response.headers['set-cookie'].join(';');
            // console.log(body,gCookie);
            callback && callback();
            // console.log(response)
        }

    })
}


function postForNew(theurl, thebody) {
    var d = new Date();
    var options = {
        method: 'POST',
        url: theurl,
        headers: {
            // 'postman-token': 'fba913cf-0c7a-304d-6f64-79340cdc9deb',
            'cache-control': 'no-cache',
            'origin': 'http://evil.com/',
            // 'cookie': 'caipiao_uname=clientadmin;'+response.headers['set-cookie'][0],
            'cookie': gCookie,
            'accept-language': 'zh-CN,zh;q=0.8,en;q=0.6',
            'accept-encoding': 'gzip, deflate, sdch',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1',
            'x-devtools-emulate-network-conditions-client-id': '8494093f-ec53-47db-bf82-d1f6ca273fca',
            'upgrade-insecure-requests': '1'
        },
        body: thebody
    };
    request(options, (error, response, body) => {
        // console.log(error, body);
        if (!error) {
            // console.log(body);
            // console.log(response)
        }

    })
}

//开奖号一位变成两位
function Kjs1Change2(str) {
    if (str.length === 1) {
        return '0' + str;
    } else {
        return str;
    }
}


function NewBSpiderOfficeQxc(url, num) {
    var exp1 = '<tbody>';
    var exp2 = '<tr>';
    var kjs = [];

    request(url, (error, response, body) => {
        if (!error) {
            var ars1 = body.split(exp1);
            // console.log(ars1)
            var ars2 = ars1[1].split(exp2);
            // console.log(ars2.length);
            for (var i = 1; i <= num; i++) {
                var kgtqh = '20' + ars2[i].split('>')[1].split('<')[0];
                // console.log(kgtqh);        
                var tmpkjs1 = ars2[i].split('>')[3].split('<')[0];
                var tmpkjs2 = tmpkjs1.split('');
                for (var j = 0; j < tmpkjs2.length; j++) {
                    kjs[j] = Kjs1Change2(tmpkjs2[j]);
                }

                var time_stamp = new Date().getTime() / 1000;
                var data1 = JSON.stringify({
                    "numbers": [{
                        "name": "七星彩",
                        "period": kgtqh,
                        "timestamp": time_stamp,
                        "datafrom": 'of',
                        "numarray": kjs
                    }]
                });
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}


function NewBSpiderOfficePl5(url, num) {
    var exp1 = '<tbody>';
    var exp2 = '<tr>';
    var kjs = [];

    request(url, (error, response, body) => {
        if (!error) {
            var ars1 = body.split(exp1);
            // console.log(ars1)
            var ars2 = ars1[1].split(exp2);
            // console.log(ars2.length);
            for (var i = 1; i <= num; i++) {
                var kgtqh = '20' + ars2[i].split('>')[1].split('<')[0];
                // console.log(kgtqh);        
                var tmpkjs1 = ars2[i].split('>')[3].split('<')[0];
                kjs = tmpkjs1.split(' ');


                var time_stamp = new Date().getTime() / 1000;
                var data1 = JSON.stringify({
                    "numbers": [{
                        "name": "排列3",
                        "period": kgtqh,
                        "timestamp": time_stamp,
                        "datafrom": 'of',
                        "numarray": kjs
                    }]
                });
                // console.log(data1);
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}

function NewSpiderBjoffical(iCaizhong, n) {
    var url;
    var caizhong;
    if (iCaizhong === 'PK10') {
        url = 'http://www.bwlc.gov.cn/bulletin/prevtrax.html';
        caizhong = '北京赛车PK10';
    } else if (iCaizhong === '快3') {
        url = 'http://www.bwlc.gov.cn/bulletin/prevqck3.html';
        caizhong = '北京快3';
    }

    if (n > 30) {
        n = 30;
    }

    request(url, (error, response, body) => {
        if (!error) {
            var exp = `<tr class=`;
            var ars = body.split(exp);
            if (ars.length <= 1) {
                // console.log("undefined exit")
                return;
            }
            var kgtqh;

            for (i = 1; i <= n; i++) {
                // console.log(ars[i]);
                // console.log(i);
                var haf = ars[i].split('<td');
                if (iCaizhong === 'PK10') {
                    kgtqh = '00' + haf[1].split('>')[1].split('</')[0];
                } else if (iCaizhong === '快3') {
                    kgtqh = '150' + haf[1].split('>')[1].split('</')[0];
                }
                var tmpkjs = haf[2].split('>')[1].split('</')[0];
                var kjs = tmpkjs.split(',');

                var time_stamp = new Date().getTime() / 1000;
                var numarray = [];
                if (iCaizhong === 'PK10') {
                    numarray = [kjs[0], kjs[1], kjs[2], kjs[3], kjs[4], kjs[5], kjs[6], kjs[7], kjs[8], kjs[9]];
                } else if (iCaizhong === '快3') {
                    numarray = [kjs[0], kjs[1], kjs[2]];
                }

                var data1 = JSON.stringify({
                    "numbers": [{
                        "name": caizhong,
                        "period": kgtqh,
                        "timestamp": time_stamp,
                        "datafrom": 'test',
                        "numarray": numarray
                    }]
                });

                // console.log(data1);
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
                // console.log(kgtqh,numarray);
            }
        }
    })
}



function NewBSpiderOld88K3(portout, qishu) {
    var caizhong = '';
    switch (portout) {
        case 8095:
            caizhong = '北京快3';
            break;
        case 8096:
            caizhong = '吉林快3';
            break;
        case 8093:
            caizhong = '内蒙古快3';
            break;
        case 8101:
            caizhong = '河北快3';
            break;
        case 8106:
            caizhong = '江苏快3';
            break;
        case 8122:
            caizhong = '贵州快3';
            break;
        case 8112:
            caizhong = '甘肃快3';
            break;
        case 8126:
            caizhong = '青海快3';
            break;
        case 8128:
            caizhong = '湖北快3';
            break;
        case 8129:
            caizhong = '江西快3';
            break;
        case 8117:
            caizhong = '福建快3';
            break;
        case 8116:
            caizhong = '安徽快3';
            break;
        case 8121:
            caizhong = '宁夏快3';
            break;
        default:
            caizhong = '';
            break;
    }
    if (caizhong === '') {
        return null;
    }
    request('http://123.57.138.66:' + portout + '/InitInfSrv?', (error, response, body) => {
        if (!error) {
            var obj = JSON.parse(body);

            for (var i = 0; i < qishu; i++) {
                var e = obj[i];
                var kgt = e.KGTime;
                var qh = e.Qh;
                if (qh < 10) {
                    qh = '0' + qh;
                }

                var time_stamp = new Date().getTime() / 1000;
                var data1 = JSON.stringify({
                    "numbers": [{
                        "name": caizhong,
                        "period": kgt + qh,
                        "timestamp": time_stamp,
                        "datafrom": 'Old',
                        "numarray": [e.Kj1.toString(), e.Kj2.toString(), e.Kj3.toString()]
                    }]
                });
                // console.log(data1);
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}

function NewBSpiderOld8811x5(portout, qishu) {
    var caizhong = '';
    switch (portout) {
        case 8083:
            caizhong = '天津11选5';
            break;
        case 8087:
            caizhong = '山东11选5';
            break;
        case 8088:
            caizhong = '北京11选5';
            break;
        case 8089:
            caizhong = '山西11选5';
            break;
        case 8091:
            caizhong = '广东11选5';
            break;
        case 8092:
            caizhong = '内蒙古11选5';
            break;
        case 8094:
            caizhong = '甘肃11选5';
            break;
        case 8097:
            caizhong = '黑龙江11选5';
            break;
        case 8098:
            caizhong = '吉林11选5';
            break;
        case 8102:
            caizhong = '河北11选5';
            break;
        case 8103:
            caizhong = '上海11选5';
            break;
        case 8104:
            caizhong = '陕西11选5';
            break;
        case 8107:
            caizhong = '浙江11选5';
            break;
        case 8111:
            caizhong = '宁夏11选5';
            break;
        case 8113:
            caizhong = '江西11选5';
            break;
        case 8114:
            caizhong = '江苏11选5';
            break;
        case 8115:
            caizhong = '安徽11选5';
            break;
        case 8118:
            caizhong = '福建11选5';
            break;
        case 8120:
            caizhong = '贵州11选5';
            break;
        case 8123:
            caizhong = '云南11选5';
            break;
        case 8125:
            caizhong = '青海11选5';
            break;
        case 8127:
            caizhong = '湖北11选5';
            break;
        case 8131:
            caizhong = '金7乐';
            break;
        case 8108:
            caizhong = '浙江福彩快乐彩';
            break;
        default:
            caizhong = '';
            break;
    }
    if (caizhong === '') {
        // console.log(portout);
        return null;
    }
    request('http://123.57.138.66:' + portout + '/InitInfSrv?', (error, response, body) => {
        if (!error) {
            var obj = JSON.parse(body);

            for (var i = 0; i < qishu; i++) {
                var e = obj[i];
                var kgt = e.KGTime;
                var qh = e.Qh;
                if (qh < 10) {
                    qh = '0' + qh;
                }

                var kjs = [];
                kjs[0] = Kjs1Change2(e.Kj1.toString());
                kjs[1] = Kjs1Change2(e.Kj2.toString());
                kjs[2] = Kjs1Change2(e.Kj3.toString());
                kjs[3] = Kjs1Change2(e.Kj4.toString());
                kjs[4] = Kjs1Change2(e.Kj5.toString());

                var time_stamp = new Date().getTime() / 1000;

                var data1 = JSON.stringify({
                    "numbers": [{
                        "name": caizhong,
                        "period": kgt + qh,
                        "timestamp": time_stamp,
                        "datafrom": 'Old',
                        "numarray": [kjs[0], kjs[1], kjs[2], kjs[3], kjs[4]]
                    }]
                });

                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}



function NewBSpiderOld88k10(portout, qishu) {
    var caizhong = '';
    switch (portout) {
        case 8084:
            caizhong = '天津快乐十分';
            break;
        case 8099:
            caizhong = '广东快乐十分';
            break;
        case 8110:
            caizhong = '山西快乐十分';
            break;
        case 8105:
            caizhong = '陕西快乐十分';
            break;
        case 8124:
            caizhong = '云南快乐十分';
            break;
        case 8130:
            caizhong = '黑龙江快乐十分';
            break;
        default:
            caizhong = '';
            break;
    }
    if (caizhong === '') {
        // console.log(portout);
        return null;
    }
    request('http://123.57.138.66:' + portout + '/InitInfSrv?', (error, response, body) => {
        if (!error) {
            var obj = JSON.parse(body);
            for (var i = 0; i < qishu; i++) {
                var e = obj[i];
                var kgt = e.KGTime;
                var qh = e.Qh;
                if (qh < 10) {
                    qh = '0' + qh;
                }

                var kjs = [];
                kjs[0] = Kjs1Change2(e.Kj1.toString());
                kjs[1] = Kjs1Change2(e.Kj2.toString());
                kjs[2] = Kjs1Change2(e.Kj3.toString());
                kjs[3] = Kjs1Change2(e.Kj4.toString());
                kjs[4] = Kjs1Change2(e.Kj5.toString());
                kjs[5] = Kjs1Change2(e.Kj6.toString());
                kjs[6] = Kjs1Change2(e.Kj7.toString());
                kjs[7] = Kjs1Change2(e.Kj8.toString());

                var time_stamp = new Date().getTime() / 1000;

                var data1 = JSON.stringify({
                    "numbers": [{
                        "name": caizhong,
                        "period": kgt + qh,
                        "timestamp": time_stamp,
                        "datafrom": 'Old',
                        "numarray": [kjs[0], kjs[1], kjs[2], kjs[3], kjs[4], kjs[5], kjs[6], kjs[7]]
                    }]
                });
                // console.log(data1);
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}


function NewBSpiderdzzAllGetMore(url, caizhong) {
    var options = {
        method: 'GET',
        url: url,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36',
            'cache-control': 'no-cache'
        }
    };
    request(options, (error, response, body) => {
        if (!error) {
            var exp = ` data-pcode="`;
            var ars = body.split(exp);

            for (var i = ars.length - 1; i < ars.length; i++) {
                // for (var i = 1; i < ars.length; i++) {
                var kgt = ars[i].slice(2, 8);
                var qh = ars[i].slice(10, 12);

                var haf = ars[i].split('<i></i><em');
                var kjs = []
                var time_stamp = new Date().getTime() / 1000;

                if (caizhong.indexOf("快10") >= 0) {
                    for (var j = 2; j < 10; j++) {
                        var nums = haf[j].split('>')[1].split('<')[0];
                        kjs[j - 2] = Kjs1Change2(nums);
                    }
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgt + qh,
                            "timestamp": time_stamp,
                            "datafrom": 'dzm',
                            "numarray": [kjs[0], kjs[1], kjs[2], kjs[3], kjs[4], kjs[5], kjs[6], kjs[7]]
                        }]
                    });
                }
                if (caizhong.indexOf("11选5") >= 0) {
                    for (var j = 2; j < 7; j++) {
                        var nums = haf[j].split('>')[1].split('<')[0];
                        kjs[j - 2] = Kjs1Change2(nums);
                    }
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgt + qh,
                            "timestamp": time_stamp,
                            "datafrom": 'dzm',
                            "numarray": [kjs[0], kjs[1], kjs[2], kjs[3], kjs[4]]
                        }]
                    });
                }
                if (caizhong.indexOf("快3") >= 0) {
                    for (var j = 2; j < 5; j++) {
                        var nums = haf[j].split('>')[1].split('<')[0];
                        kjs[j - 2] = nums;
                    }
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgt + qh,
                            "timestamp": time_stamp,
                            "datafrom": 'dzm',
                            "numarray": [kjs[0], kjs[1], kjs[2]]
                        }]
                    });
                }
                if (caizhong.indexOf("481") >= 0) {
                    for (var j = 2; j < 6; j++) {
                        var nums = haf[j].split('>')[1].split('<')[0];
                        kjs[j - 2] = nums;
                    }
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgt + qh,
                            "timestamp": time_stamp,
                            "datafrom": 'dzm',
                            "numarray": [kjs[0], kjs[1], kjs[2], kjs[3]]
                        }]
                    });
                }
                // console.log(data1)
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}


function NewBSpiderMobHebK3Official(url, num) {
    var exp = `class="no"`
    request(url, (error, response, body) => {
        if (!error) {
            var ars = body.split(exp);
            for (i = 1; i <= num; i++) {
                var kgt = ars[i].slice(2, 8);
                var qh = ars[i].slice(9, 11);
                var kgtqh = kgt + qh;
                var haf = ars[i].split('red');
                var tmpkjs = [];
                var kjs = [];

                for (var j = 1; j <= 3; j++) {
                    tmpkjs[j - 1] = haf[j].split('">')[1].split('</')[0];
                    kjs[j - 1] = tmpkjs[j - 1].toString();
                }

                var time_stamp = new Date().getTime() / 1000;

                var data1 = JSON.stringify({
                    "numbers": [{
                        "name": "河北快3",
                        "period": kgtqh,
                        "timestamp": time_stamp,
                        "datafrom": 'ofm',
                        "numarray": [kjs[0], kjs[1], kjs[2]]
                    }]
                });


                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
                // httpGetAsync('http://123.57.138.66:' + 8101 +'/InsertKjInf?KGTime=' + kgtqh.slice(0,6) + '&Qh=' + kgtqh.slice(6,8) + '&ServerIP=' + 'ofm' + '&Kj1=' +
                //         kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2],
                //         function(body) {
                //     })
            }
        }
    })
}

function NewSpiderMobWeb(url, caizhong) {
    request(url, (error, response, body) => {
        if (!error) {
            var exp = `<tr>`;
            var ars = body.split(exp);

            for (var i = 2; i < ars.length; i++) {
                var haf = ars[i].split('<td>');

                var d = new Date();
                var kjs = [];
                var ballnum;
                var kgtqh;

                // console.log(port);
                if (caizhong === '大乐透') {
                    kgtqh = '20' + haf[1].slice(0, 5);
                    ballnum = 7;
                }
                if (caizhong === '排列3') {
                    kgtqh = '20' + haf[1].slice(0, 5);
                    ballnum = 5;
                }
                if (caizhong === '双色球') {
                    kgtqh = '20' + haf[1].slice(0, 5);
                    ballnum = 7;
                }
                if (caizhong === '3D') {
                    kgtqh = '20' + haf[1].slice(0, 5);
                    ballnum = 3;
                }

                var haf1 = haf[2].split('"ball');

                for (var j = 1; j <= ballnum; j++) {
                    kjs[j - 1] = haf1[j].split('">')[1].split('</')[0];
                }

                var time_stamp = d.getTime() / 1000;

                if (caizhong === '大乐透') {
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgtqh,
                            "timestamp": time_stamp,
                            "datafrom": 'mw',
                            "numarray": [kjs[0].toString(), kjs[1].toString(), kjs[2].toString(), kjs[3].toString(), kjs[4].toString(), kjs[5].toString(), kjs[6].toString()]
                        }]
                    });
                }
                if (caizhong === '排列3') {
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgtqh,
                            "timestamp": time_stamp,
                            "datafrom": 'mw',
                            "numarray": [kjs[0].toString(), kjs[1].toString(), kjs[2].toString(), kjs[3].toString(), kjs[4].toString()]
                        }]
                    });
                }
                if (caizhong === '双色球') {
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgtqh,
                            "timestamp": time_stamp,
                            "datafrom": 'mw',
                            "numarray": [kjs[0].toString(), kjs[1].toString(), kjs[2].toString(), kjs[3].toString(), kjs[4].toString(), kjs[5].toString(), kjs[6].toString()]
                        }]
                    });
                }
                if (caizhong === '3D') {
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgtqh,
                            "timestamp": time_stamp,
                            "datafrom": 'mw',
                            "numarray": [kjs[0].toString(), kjs[1].toString(), kjs[2].toString()]
                        }]
                    });
                }
                // console.log(data1)
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}