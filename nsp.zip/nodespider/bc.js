var request = require('request');
var tmstmp;

setInterval(function() {
    var dd = new Date()
    var d = dd.getHours();
    tmstmp = dd.getHours().toString() + ':' + dd.getMinutes().toString() + ':' + dd.getSeconds().toString()

    if (d < 24 && d > 7) {
        // console.log("*******************",tmstmp,"**************************");
        //快乐十分杂源集合

        SpiderBcAll('http://server.baibaocp.com/web/klsflist/lotid/10305/num/1', '8105', 'k10');
        SpiderBcAll('http://server.baibaocp.com/web/klsflist/lotid/10304/num/1', '8084', 'k10');


        // 快三
        // SpiderBcAll('http://server.baibaocp.com/web/kslist/lotid/10413/num/1', '8112', 'k3');
        SpiderBcAll('http://server.baibaocp.com/web/kslist/lotid/10403/num/1', '8101', 'k3');
        SpiderBcAll('http://server.baibaocp.com/web/kslist/lotid/10406/num/1', '8095', 'k3');
        // SpiderBcAll('http://server.baibaocp.com/web/kslist/lotid/10401/num/1','8096', 'k3');
        SpiderBcAll('http://server.baibaocp.com/web/jqllist/lotid/10901/num/50', '8131', 'j7');

        //11选5杂源集合
        SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10112/num/1', '8104', '11x5');
        SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10102/num/1', '8098', '11x5');
        //SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10101/num/1', '8097', '11x5');
        SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10124/num/1', '8094', '11x5');
        SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10109/num/1', '8083', '11x5');
        SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10106/num/1', '8113', '11x5');
    }
}, 15 * 1000)



function SpiderBcAll(url, port, caizhong) {
    request(url, (error, response, body) => {
        if (!error) {
            var obj = JSON.parse(body);
            // console.log(obj.data.list);
            obj.data.list.forEach(function(e) {
                if (caizhong === 'k3') {
                    var kjs = [e.ball1, e.ball2, e.ball3];
                }
                if (port === '8095') {
                    var kgt = '150' + e.issue.slice(0, 3);
                    var qh2 = e.issue.slice(-2);
                    kjs = kjs.sort();
                } else {
                    var kgt = e.issue.slice(0, 6);
                    var qh2 = e.issue.slice(-2);
                }

                var d = new Date();
                // console.log(e,kgt,qh2);
                // alert(e,kgt,qh2);
                if (caizhong === '11x5') {
                    request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh2 + '&ServerIP=' + 'bc' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                        e.ball1 + '&Kj2=' + e.ball2 + '&Kj3=' + e.ball3 + '&Kj4=' + e.ball4 + '&Kj5=' + e.ball5, (err, resp, body) => {
                            if (body && body !== 'Insert Exit ') {
                                console.log(port, tmstmp, body, kgt, qh2)
                            }
                        })
                }
                if (caizhong === 'j7') {
                    request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh2 + '&ServerIP=' + 'bc' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                        e.ball1 + '&Kj2=' + e.ball2 + '&Kj3=' + e.ball3 + '&Kj4=' + e.ball4, (err, resp, body) => {
                            if (body && body !== 'Insert Exit ') {
                                console.log(port, tmstmp, body, kgt, qh2)
                            }
                        })
                }

                if (caizhong === 'k3') {
                    request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh2 + '&ServerIP=' + 'bc' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                        kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2], (err, resp, body) => {
                            if (body && body !== 'Insert Exit ') {
                                console.log(port, tmstmp, body, kgt, qh2)
                            }
                        })
                }
                if (caizhong === 'k10') {
                    request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh2 + '&ServerIP=' + 'bc' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                        e.ball1 + '&Kj2=' + e.ball2 + '&Kj3=' + e.ball3 + '&Kj4=' + e.ball4 + '&Kj5=' + e.ball5 + '&Kj6=' + e.ball6 + '&Kj7=' + e.ball7 + '&Kj8=' + e.ball8, (err, resp, body) => {
                            if (body && body !== 'Insert Exit ') {
                                console.log(port, tmstmp, body, kgt, qh2)
                            }
                        })
                }
            })
        }
    })
}


function IsInsertFlag(hafkjs) {
    var hafkjs = hafkjs.sort();
    for (var i = 0; i < hafkjs.length; i++) {

        if (isNaN(hafkjs[i])) {
            return false;
        }
        if (hafkjs[i] === 0) {
            // console.log(false + '0');
            return false;
        }
        if (hafkjs[i] === hafkjs[i + 1]) {
            // console.log(false + '1');
            return false;
        }
    }
    // console.log(true + '0');
    return true;
}

function IsK3InsertFlag(hafkjs) {
    var hafkjs = hafkjs.sort();
    for (var i = 0; i < hafkjs.length; i++) {

        if (isNaN(hafkjs[i])) {
            // console.log(false + '0');
            return false;
        }
        if (hafkjs[i] === 0) {
            // console.log(false + '0');
            return false;
        }
    }
    // console.log(true + '0');
    return true;
}