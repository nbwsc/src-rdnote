var request = require('request');
// var http = require("http"); //http request
// var iconv = require('iconv-lite'); //gbk convert*
var tmstmp;


setInterval(function () {
    var dd = new Date()
    var d = dd.getHours();
    tmstmp = dd.getHours().toString() + ':' +dd.getMinutes().toString() + ':' + dd.getSeconds().toString()

    if (d<24 && d >7) {
        // console.log("*******************",tmstmp,"**************************");
        //快乐十分杂源集合
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/shanxikl10/kl10-001/lastData.html?pcode=20171231-100', '8110', 'k10',1);
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/gdkl10/kl10-001/lastData.html?pcode=20171231-100', '8099', 'k10',1);
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/ynkl10/kl10-001/lastData.html?pcode=20171231-100', '8124', 'k10',1);
        // SpiderBcAll('http://server.baibaocp.com/web/klsflist/lotid/10305/num/1', '8105', 'k10');
        // SpiderBcAll('http://server.baibaocp.com/web/klsflist/lotid/10304/num/1', '8084', 'k10');


        // 快三
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/fjk3/k3-001/lastData.html?pcode=20171231-100', '8117', 'k3',1);
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/jlk3/k3-001/lastData.html?pcode=20171231-100', '8096', 'k3',1);
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/nmgk3/k3-001/lastData.html?pcode=20171231-100', '8093', 'k3',1);
        // // SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/nxk3/k3-001/lastData.html?pcode=20171231-100', '8121', 'k3',1);
        // // SpiderBcAll('http://server.baibaocp.com/web/kslist/lotid/10413/num/1', '8112', 'k3');
        // SpiderBcAll('http://server.baibaocp.com/web/kslist/lotid/10403/num/1', '8101', 'k3');
        // SpiderBcAll('http://server.baibaocp.com/web/kslist/lotid/10406/num/1', '8095', 'k3');
        // SpiderBcAll('http://server.baibaocp.com/web/kslist/lotid/10401/num/1','8096', 'k3');

        
        //11选5杂源集合
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/fj11x5/11x5-001/lastData.html?pcode=20171231-100', '8118', '11x5',1);
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/hb11x5/11x5-001/lastData.html?pcode=20171231-100', '8102', '11x5',1);
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/gs11x5/11x5-001/lastData.html?pcode=20171231-100','8094','11x5',1);
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/gz11x5/11x5-001/lastData.html?pcode=20171231-100','8120','11x5',1);
        SpiderdzzAllGetMore('http://www.dzzst.com/m/chart/yn11x5/11x5-001/lastData.html?pcode=20171231-100','8123','11x5',1);
        // SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10112/num/1', '8104', '11x5');
        // SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10102/num/1', '8098', '11x5');
        // SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10124/num/1','8094','11x5');
        // SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10109/num/1', '8083', '11x5');
        // SpiderBcAll('http://server.baibaocp.com/web/syxwlist/lotid/10106/num/1', '8113', '11x5');
    }
}, 15 * 1000)





function IsInsertFlag(hafkjs){
    var hafkjs = hafkjs.sort();
    for(var i =0; i < hafkjs.length; i++){

        if(isNaN(hafkjs[i])) {
            return false;
        }
        if(hafkjs[i] == 0){
            // console.log(false + '0');
            return false;
        }
        if (hafkjs[i]==hafkjs[i+1]){
            // console.log(false + '1');
            return false;
        }
    }
    // console.log(true + '0');
    return true;
}

function IsK3InsertFlag(hafkjs){
    var hafkjs = hafkjs.sort();
    for(var i =0; i < hafkjs.length; i++){

        if(isNaN(hafkjs[i])) {
            // console.log(false + '0');
            return false;
        }
        if(hafkjs[i] == 0){
            // console.log(false + '0');
            return false;
        }
    }
    // console.log(true + '0');
    return true;
}

function SpiderdzzAllGetMore(url, port, caizhong,num) {
    var d = new Date();
    var options = { method: 'GET',
                    url: url,
                    headers: 
                       { 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36',
                         'cache-control': 'no-cache' } };
    request(options, (error, response, body) => {
        if (!error) {
            var exp = "data-pcode=\"";
            var ars = body.split(exp);

            for (var i = ars.length-1; i >= ars.length-num; i--) {
                var kgt = ars[i].slice(2, 8);
                var qh = ars[i].slice(10,12);

                // console.log(kgt,qh)

                var haf = ars[i].split('<i></i><em');
                var kjs = [];
                var tmpkjs = [];

                if(caizhong == 'k10'){
                    for (var j = 2; j < 10; j++) {
                        var nums = haf[j].split('>')[1].split('<')[0];
                        kjs[j -2] = nums;
                        tmpkjs[j-2] = nums;
                    }

                    if(IsInsertFlag(tmpkjs)) {
                        request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'dz' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                            kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3] + '&Kj5=' + kjs[4]+ '&Kj6=' + kjs[5]+ '&Kj7=' + kjs[6]+ '&Kj8=' + kjs[7], (err, resp, body) => {
                                if(body && body !== 'Insert Exit ')
                                    console.log(port,body,kjs, kgt, qh,tmstmp)
                        })
                    }
                }
                if(caizhong == '11x5'){
                    for (var j = 2; j < 7; j++) {
                        var nums = haf[j].split('>')[1].split('<')[0];
                        kjs[j -2] = nums;
                        tmpkjs[j-2] = nums;
                    }

                    if(IsInsertFlag(tmpkjs)) {
                        request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'dz' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                            kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3] + '&Kj5=' + kjs[4], (err, resp, body) => {
                                if(body && body !== 'Insert Exit ')
                                    console.log(port,body,kjs, kgt, qh,tmstmp)
                        })
                    }
                }
                if(caizhong == 'k3'){
                    for (var j = 2; j < 5; j++) {
                        var nums = haf[j].split('>')[1].split('<')[0];
                        kjs[j -2] = nums;
                        tmpkjs[j-2] = nums;
                    }

                    if(IsK3InsertFlag(tmpkjs)) {
                        request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'dz' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                            kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2], (err, resp, body) => {
                                if(body && body !== 'Insert Exit ')
                                    console.log(port,body,kjs, kgt, qh,tmstmp)
                        })
                    }
                }
            }
        }
    })
}


