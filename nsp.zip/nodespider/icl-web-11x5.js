var request = require('request');
// var http = require("http"); //http request
// var iconv = require('iconv-lite'); //gbk convert*


setInterval(function () {
    var dd = new Date()
    var d = dd.getHours();
    var tmstmp = dd.getHours().toString() + ':' +dd.getMinutes().toString() + ':' + dd.getSeconds().toString()

    if (d<24 && d >7) {
        //console.log("*******************",tmstmp,"**************************");
        SpiderWeb11x5('http://chart.icaile.com/tj11x5.php?op=dcjb&num=18', '8083');
        // SpiderWeb11x5('http://chart.icaile.com/sd11x5.php?op=dcjb&num=18', '8087');
        SpiderWeb11x5('http://chart.icaile.com/bj11x5.php?op=dcjb&num=18', '8088');
        SpiderWeb11x5('http://chart.icaile.com/sx11x5.php?op=dcjb&num=18', '8089');
        SpiderWeb11x5('http://chart.icaile.com/gd11x5.php?op=dcjb&num=18', '8091');
        SpiderWeb11x5('http://chart.icaile.com/nmg11x5.php?op=dcjb&num=18', '8092');
        SpiderWeb11x5('http://chart.icaile.com/gs11x5.php?op=dcjb&num=18', '8094');
        SpiderWeb11x5('http://chart.icaile.com/hlj11x5.php?op=dcjb&num=18', '8097');
        SpiderWeb11x5('http://chart.icaile.com/jl11x5.php?op=dcjb&num=18', '8098');
        SpiderWeb11x5('http://chart.icaile.com/heb11x5.php?op=dcjb&num=18', '8102');
        // SpiderWeb11x5('http://chart.icaile.com/sh11x5.php?op=dcjb&num=18', '8103');
        SpiderWeb11x5('http://chart.icaile.com/shx11x5.php?op=dcjb&num=18', '8104');
        // SpiderWeb11x5('http://chart.icaile.com/zj11x5.php?op=dcjb&num=18', '8107');
        SpiderWeb11x5('http://chart.icaile.com/nx11x5.php?op=dcjb&num=18', '8111');
        SpiderWeb11x5('http://chart.icaile.com/jx11x5.php?op=dcjb&num=18', '8113');
        SpiderWeb11x5('http://chart.icaile.com/js11x5.php?op=dcjb&num=100', '8114');
        SpiderWeb11x5('http://chart.icaile.com/ah11x5.php?op=dcjb&num=18', '8115');
        SpiderWeb11x5('http://chart.icaile.com/fj11x5.php?op=dcjb&num=18', '8118');
        SpiderWeb11x5('http://chart.icaile.com/gz11x5.php?op=dcjb&num=18', '8120');
        SpiderWeb11x5('http://chart.icaile.com/yn11x5.php?op=dcjb&num=18', '8123');
        // SpiderWeb11x5('http://chart.icaile.com/qh11x5.php?op=dcjb&num=18', '8125');
        SpiderWeb11x5('http://chart.icaile.com/hb11x5.php?op=dcjb&num=18', '8127');
    }
}, 20 * 1000)



// function requestUrl(url,handleBody) {

//     http.get(url, function(res) {
//         var arrBuf = [];
//         var bufLength = 0;
//         res.on("data", function(chunk) {
//             arrBuf.push(chunk);
//             bufLength += chunk.length;
//           })
//           .on("end", function() { //response callback
//             // arrBuf是个存byte数据块的数组，byte数据块可以转为字符串，数组可不行
//             // bufferhelper也就是替你计算了bufLength而已 
//             var chunkAll = Buffer.concat(arrBuf, bufLength);
//             var content = iconv.decode(chunkAll, 'gb2312'); // utf-8 content
//             // fs.writeFileSync('data',content)
//             handleBody(content);
//         });
//     });
// }


function SpiderWeb11x5(url, port) {
    request(url, (error, response, body) => {
        if (!error) {
            var exp = `class="chart-bg-qh">`;
            var ars = body.split(exp);

            for (var i = 1; i < ars.length; i++) {
                var qh = ars[i].split('</td>')[0];
                var haf = ars[i].split('cc');
                var kjs = []
                for (var j in haf) {
                    var nums = haf[j].split('>')[1].split('<')[0];
                    if (nums.length === 6) {
                        switch (nums) {
                            case 'EMDE=M':
                                // console.log(1);
                                kjs[j - 1] = 1;
                                break;
                            case 'IMDI=M':
                                // console.log(2);
                                kjs[j - 1] = 2;
                                break;
                            case 'MMDM=M':
                                // console.log(3);
                                kjs[j - 1] = 3;
                                break;
                            case 'QMDQ=M':
                                // console.log(4);
                                kjs[j - 1] = 4;
                                break;
                            case 'UMDU=M':
                                // console.log(5);
                                kjs[j - 1] = 5;
                                break;
                            case 'YMDY=M':
                                // console.log(6);
                                kjs[j - 1] = 6;
                                break;
                            case 'cMDc=M':
                                // console.log(6);
                                kjs[j - 1] = 7;
                                break;
                            case 'gMDg=M':
                                // console.log(6);
                                kjs[j - 1] = 8;
                                break;
                            case 'kMDk=M':
                                // console.log(6);
                                kjs[j - 1] = 9;
                                break;
                            case 'AMTA=M':
                                // console.log(6);
                                kjs[j - 1] = 10;
                                break;
                            case 'EMTE=M':
                                // console.log(6);
                                kjs[j - 1] = 11;
                                break;
                            case 'IMTI=M':
                                // console.log(6);
                                kjs[j - 1] = 12;
                                break;
                            default:
                                // console.log('err:', nums)
                                break;
                        }
                    }
                }
                // console.log(kjs, qh);
                var kgt = qh.slice(0, 6);
                var qh2 = qh.slice(-2);
                var d = new Date();
                // console.log(kjs, kgt, qh2)
                request('http://123.57.138.66:' + port +'/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh2 + '&ServerIP=' + 'web' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                    kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3] + '&Kj5=' + kjs[4],(error, response, body) => {
                    if(body && body !== 'Insert Exit ') {
                            console.log(port,body, kgt, qh2)
                    }
                })
            }
        }
    })
}
