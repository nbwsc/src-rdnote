var request = require('request');
var http = require("http"); //http request
// var cheerio = require('cheerio'); //xml parser*
var iconv = require('iconv-lite'); //gbk convert*
var tmstmp;

setInterval(function() {
    try {
        var dd = new Date()
        var d = dd.getHours();
        tmstmp = dd.getHours().toString() + ':' + dd.getMinutes().toString() + ':' + dd.getSeconds().toString()

        if (d < 24 && d > 7) {
            // console.log("*******************",tmstmp,"**************************");
            SpiderZhcvideok3('http://zhcvideo.com/weChat/nxk3/he189?flag=49', 8121);
            // SpiderWebJ7("http://j7l.icaile.com/zoushi/haomafengbu/", 1);
            SpiderMobWebK3('http://m.nmgk3.icaile.com/kaijiang/1', '8093');
            SpiderMobWebK3('http://m.jxk3.icaile.com/kaijiang/1', '8129');
            SpiderMobWebK10('http://m.gdkl10.icaile.com/kaijiang/1', '8099');
            SpiderMobWebK10('http://m.ynkl10.icaile.com/kaijiang/1', '8124');
            SpiderMobWebK3('http://m.jlk3.icaile.com/kaijiang/1', '8096');
            SpiderMobWebK3('http://m.jsk3.icaile.com/kaijiang/1', '8106');
            SpiderydniuK3('http://www.ydniu.com/open/122.html', '8093', 1);
            SpiderydniuK3('http://www.ydniu.com/open/84.html', '8096', 1);
            Spiderydniu11x5('http://www.ydniu.com/open/95.html', '8114', 1);
            SpiderHlj11x5Zhenghao();
            SpiderMobHebK3Official("http://m.yzfcw.com/prize/list.php?lotteryType=HBP3", 1);
            SpiderMobWeb11x5('http://m.shx11x5.icaile.com/kaijiang/1', '8104');
            SpiderMobWeb11x5('http://m.js11x5.icaile.com/kaijiang/1', '8114');
        }
    } catch (e) {
        console.log(new Date(), e)
    }
}, 15 * 1000)



function requestUrl(url, handleBody) {

    http.get(url, function(res) {
        var arrBuf = [];
        var bufLength = 0;
        res.on("data", function(chunk) {
                arrBuf.push(chunk);
                bufLength += chunk.length;
            })
            .on("end", function() { //response callback
                // arrBuf是个存byte数据块的数组，byte数据块可以转为字符串，数组可不行
                // bufferhelper也就是替你计算了bufLength而已 
                var chunkAll = Buffer.concat(arrBuf, bufLength);
                var content = iconv.decode(chunkAll, 'gb2312'); // utf-8 content
                // fs.writeFileSync('data',content)
                handleBody(content);
            });
    });
}

function SpiderHlj11x5Zhenghao() {
    requestUrl('http://www.zhenghao.cn/888hlj115/openall.php', function(body) {
        var exp = `http://www.zhenghao.cn/888hlj115/conf/openday`;
        var ars = body.split(exp);
        if (ars.length <= 1) {
            console.log("undefined error in zhenghao");
            return;
        }
        var haf = ars[1].split('/')[1].split('.')[0];
        requestUrl('http://www.zhenghao.cn/888hlj115/conf/openday/' + haf + '.html', function(body) {
            var exp1 = 'color=green size=+1><b><img';
            var ars1 = body.split(exp1);
            var ars2 = body.split('<font color=red size=+1>');

            var kgt1 = ars2[1].split('<b>')[1].split('日')[0];
            var kgt = kgt1.replace(/-/g, "");
            var kgt = kgt.slice(2);

            var qh = ars1.length - 1;

            var haf1 = ars1[qh].split("src=/images");

            var kjs = [];

            for (var i = 1; i < 6; i++) {
                // for (var i in ars) {
                var nums = haf1[i].split('/')[1].split('.')[0];
                kjs[i - 1] = nums;
            }

            var d = new Date();

            request('http://123.57.138.66:' + 8097 + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'zh' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3] + '&Kj5=' + kjs[4], (error, response, body) => {
                    if (body && body !== 'Insert Exit ')
                        console.log(8097, body, kjs, kgt, qh, tmstmp)
                })
        })
    })
}


function Spiderydniu11x5(url, port, num) {
    var d = new Date();
    request(url, (error, response, body) => {
        if (!error) {
            var exp = `<tr><td>`;
            var ars = body.split(exp);

            for (var i = 1; i <= num; i++) {
                var kgtqh = ars[1].split('期')[0].slice(-9);
                var kgt = kgtqh.slice(0, 6);
                var qh = kgtqh.slice(-2);
                // console.log(kgtqh,kgt, qh)

                var haf = ars[1].split('open_ball');
                var kjs = []
                for (var j = 1; j < 6; j++) {
                    kjs[j - 1] = haf[j].split('>')[1].split('<')[0];
                }

                request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'yd' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                    kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3] + '&Kj5=' + kjs[4], (err, resp, body) => {
                        if (body && body !== 'Insert Exit ')
                            console.log(port, body, kjs, kgt, qh, tmstmp)
                    })
            }
        }
    })
}


function SpiderydniuK3(url, port, num) {
    var d = new Date();
    request(url, (error, response, body) => {
        if (!error) {
            var exp = `<tr><td>`;
            var ars = body.split(exp);

            for (var i = 1; i <= num; i++) {
                var kgtqh1 = ars[1].split('期')[0].slice(-9);
                var tmpkgtqh = parseInt(kgtqh1);
                // console.log(kgtqh1)
                if (tmpkgtqh < 100000000) {
                    var kgt = kgtqh1.slice(1, 7);
                    var qh = kgtqh1.slice(-2);
                } else {
                    var kgt = kgtqh1.slice(0, 6);
                    var qh = kgtqh1.slice(-2);
                }

                var haf = ars[1].split('open_ball');
                var kjs = []
                for (var j = 1; j < 4; j++) {
                    kjs[j - 1] = haf[j].split('>')[1].split('<')[0];
                }

                request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'yd' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                    kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2], (err, resp, body) => {
                        if (body && body !== 'Insert Exit ')
                            console.log(port, body, kjs, kgt, qh, tmstmp)
                    })
            }
        }
    })
}


function SpiderMobWebK3(url, port) {
    request(url, (error, response, body) => {
        if (!error) {
            var exp = `<tr>`;
            var ars = body.split(exp);

            for (var i = 2; i < ars.length; i++) {
                var haf = ars[i].split('<td>');

                var d = new Date();
                var kgtyear = d.getYear().toString().slice(1, 3);
                var kgtMonth = d.getMonth() + 1;
                if (kgtMonth < 10) {
                    kgtMonth = '0' + kgtMonth;
                }

                var kgt = kgtyear + kgtMonth + haf[1].slice(0, 2);
                var qh = haf[1].slice(3, 5);

                var nums = haf[2].split('<')[0];
                var kjs = nums.split(",")

                request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'mw' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                    kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2], (err, resp, body) => {
                        if (body && body !== 'Insert Exit ')
                            console.log(port, body, kjs, kgt, qh, tmstmp)
                    })
            }
        }
    })
}


function SpiderMobWeb11x5(url, port) {
    request(url, (error, response, body) => {
        if (!error) {
            var exp = `<tr>`;
            var ars = body.split(exp);

            for (var i = 2; i < ars.length; i++) {
                var haf = ars[i].split('<td>');

                var d = new Date();
                var kjs = [];

                // console.log(port);
                var kgt = haf[1].slice(0, 6);
                if (port === '8108') {
                    var qh = haf[1].slice(8, 10);
                } else {
                    var qh = haf[1].slice(7, 9);
                }

                var haf1 = haf[2].split('"ball');

                for (var j = 1; j < 6; j++) {
                    kjs[j - 1] = haf1[j].split('">')[1].split('</')[0];
                }

                request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'mw' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                    kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3] + '&Kj5=' + kjs[4], (err, resp, body) => {
                        if (body && body !== 'Insert Exit ')
                            console.log(port, body, kjs, kgt, qh, tmstmp)
                    })
            }
        }
    })
}


function SpiderMobWebK10(url, port) {
    request(url, (error, response, body) => {
        if (!error) {
            var exp = `<tr>`;
            var ars = body.split(exp);

            for (var i = 2; i < ars.length; i++) {
                var haf = ars[i].split('<td>');

                var d = new Date();
                var kgtyear = d.getYear().toString().slice(1, 3);
                var kgtMonth = d.getMonth() + 1;
                if (kgtMonth < 10) {
                    kgtMonth = '0' + kgtMonth;
                }

                var kgt = kgtyear + kgtMonth + haf[1].slice(0, 2);
                var qh = haf[1].slice(2, 4);

                var nums = haf[2].split('<')[0];
                var kjs = nums.split(",")

                request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'mw' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                    kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3] + '&Kj5=' + kjs[4] + '&Kj6=' + kjs[5] + '&Kj7=' + kjs[6] + '&Kj8=' + kjs[7], (err, resp, body) => {
                        if (body && body !== 'Insert Exit ')
                            console.log(port, body, kjs, kgt, qh, tmstmp)
                    })
            }
        }
    })
}


function SpiderWebJ7(url, n) {
    request(url, (error, response, body) => {
        if (!error) {
            // alert(body);
            var exp = "<tr>";
            var ars = body.split(exp);

            for (i = ars.length - 6; i >= ars.length - 5 - n; i--) {

                var kgtqh = ars[i].split('>')[1].split('<')[0];
                var kgt = kgtqh.slice(0, 6);
                var qh = kgtqh.slice(-2);

                var tmpkjs = ars[i].split('>')[3].split('<')[0];
                var kjs = tmpkjs.split(",");

                request('http://123.57.138.66:8131/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'web' + '&Kj1=' +
                    kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3], (err, resp, body) => {
                        if (body && body !== 'Insert Exit ')
                            console.log("8131", body, kjs, kgt, qh, tmstmp)
                    })
            }
        }
    })
}



function SpiderZhcvideok3(url, port) {
    request(url, (error, response, body) => {
        if (!error) {
            try {
                var obj = JSON.parse(body);
                // console.log(obj);
                var kgtmp = obj.table[0];
                var qhtmp = parseInt(kgtmp.qihao);
                var d = new Date();
                var h = d.getHours();
                var kgtyear = d.getYear().toString().slice(1, 3);
                var kgtMonth = d.getMonth() + 1;
                if (kgtMonth < 10) {
                    kgtMonth = '0' + kgtMonth;
                }
                var kgtDay = d.getDate();
                if (kgtDay < 10) {
                    kgtDay = '0' + kgtDay;
                }

                if (h < 12 && qhtmp > 30) {
                    return;
                }

                var kgt = kgtyear + kgtMonth + kgtDay;
                var kjs = [];
                kjs[0] = kgtmp.q1;
                kjs[1] = kgtmp.q2;
                kjs[2] = kgtmp.q3;

                var qh;
                if (qhtmp < 10) {
                    qh = '0' + qhtmp;
                } else {
                    qh = qhtmp.toString();
                }

                request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'zhcv' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                    kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2], (err, resp, body) => {
                        if (body && body !== 'Insert Exit ')
                            console.log(port, body, kjs, kgt, qh, tmstmp)
                    })

            } catch (e) {
                console.log('337', tmstmp, e)
            }
        }
    })
}

function IsInsertFlag(hafkjs) {
    var hafkjs = hafkjs.sort();
    for (var i = 0; i < hafkjs.length; i++) {

        if (isNaN(hafkjs[i])) {
            return false;
        }
        if (hafkjs[i] === 0) {
            // console.log(false + '0');
            return false;
        }
        if (hafkjs[i] === hafkjs[i + 1]) {
            // console.log(false + '1');
            return false;
        }
    }
    // console.log(true + '0');
    return true;
}

function IsK3InsertFlag(hafkjs) {
    var hafkjs = hafkjs.sort();
    for (var i = 0; i < hafkjs.length; i++) {

        if (isNaN(hafkjs[i])) {
            // console.log(false + '0');
            return false;
        }
        if (hafkjs[i] === 0) {
            // console.log(false + '0');
            return false;
        }
    }
    // console.log(true + '0');
    return true;
}


function SpiderMobHebK3Official(url, num) {
    var exp = `class="no"`
    request(url, (error, response, body) => {
        // console.log(body)
        if (!error) {
            var ars = body.split(exp);
            for (i = 1; i <= num; i++) {
                var kgt = ars[i].slice(2, 8);
                var qh = ars[i].slice(9, 11);
                var haf = ars[i].split('red');
                var tmpkjs = [];
                var kjs = [];

                for (var j = 1; j <= 3; j++) {
                    tmpkjs[j - 1] = haf[j].split('">')[1].split('</')[0];
                    kjs[j - 1] = tmpkjs[j - 1].toString();
                }

                // console.log(kjs)
                request('http://123.57.138.66:' + 8101 + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'ofm' + '&Kj1=' +
                    kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2], (err, resp, body) => {
                        if (body && body !== 'Insert Exit ')
                            console.log(8101, body, kjs, kgt, qh, tmstmp)
                    })
            }
        }
    })
}


function SpiderWeb11x5(url, port) {
    request(url, (error, response, body) => {
        if (!error) {
            var exp = `class="chart-bg-qh">`;
            var ars = body.split(exp);

            for (var i = 1; i < ars.length; i++) {
                var qh = ars[i].split('</td>')[0];
                var haf = ars[i].split('cc');
                var kjs = []
                for (var j in haf) {
                    var nums = haf[j].split('>')[1].split('<')[0];
                    if (nums.length === 6) {
                        switch (nums) {
                            case 'EMDE=M':
                                // console.log(1);
                                kjs[j - 1] = 1;
                                break;
                            case 'IMDI=M':
                                // console.log(2);
                                kjs[j - 1] = 2;
                                break;
                            case 'MMDM=M':
                                // console.log(3);
                                kjs[j - 1] = 3;
                                break;
                            case 'QMDQ=M':
                                // console.log(4);
                                kjs[j - 1] = 4;
                                break;
                            case 'UMDU=M':
                                // console.log(5);
                                kjs[j - 1] = 5;
                                break;
                            case 'YMDY=M':
                                // console.log(6);
                                kjs[j - 1] = 6;
                                break;
                            case 'cMDc=M':
                                // console.log(6);
                                kjs[j - 1] = 7;
                                break;
                            case 'gMDg=M':
                                // console.log(6);
                                kjs[j - 1] = 8;
                                break;
                            case 'kMDk=M':
                                // console.log(6);
                                kjs[j - 1] = 9;
                                break;
                            case 'AMTA=M':
                                // console.log(6);
                                kjs[j - 1] = 10;
                                break;
                            case 'EMTE=M':
                                // console.log(6);
                                kjs[j - 1] = 11;
                                break;
                            case 'IMTI=M':
                                // console.log(6);
                                kjs[j - 1] = 12;
                                break;
                            default:
                                // console.log('err:', nums)
                                break;
                        }
                    }
                }
                // console.log(kjs, qh);
                var kgt = qh.slice(0, 6);
                var qh2 = qh.slice(-2);
                var d = new Date();
                // console.log(kjs, kgt, qh2)
                request('http://123.57.138.66:' + port + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh2 + '&ServerIP=' + 'web' + d.getHours() + d.getMinutes() + d.getSeconds() + '&Kj1=' +
                    kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3] + '&Kj5=' + kjs[4], (error, response, body) => {
                        if (body && body !== 'Insert Exit ')
                            console.log(port, body, kjs, kgt, qh, tmstmp)
                    })
            }
        }
    })
}