var request = require('request');
var http = require("http"); //http request
// var cheerio = require('cheerio'); //xml parser*
var iconv = require('iconv-lite'); //gbk convert*
var tmstmp;
var gCookie;


var logindata = JSON.stringify({
                "username": "admin",
                "password": "7c4a8d09ca3762af61e59520943dc26494f8941b"});

loginForNew('http://123.57.212.33:8000/caipiao/web/login',logindata,function(){
    setInterval(function () {
        var d = new Date().getHours();
        if (d<24 && d >7) {
            var dd = new Date()
            var d = dd.getHours();
            tmstmp = dd.getHours().toString() + ':' +dd.getMinutes().toString() + ':' + dd.getSeconds().toString()

            SpiderHlj11x5Zhenghao();
        }
    }, 15 * 1000)
})

setInterval(function() {    
    loginForNew('http://123.57.212.33:8000/caipiao/web/login',logindata);
}, 3600 * 1000)

function requestUrl(url,handleBody) {

    http.get(url, function(res) {
        var arrBuf = [];
        var bufLength = 0;
        res.on("data", function(chunk) {
            arrBuf.push(chunk);
            bufLength += chunk.length;
          })
          .on("end", function() { //response callback
            // arrBuf是个存byte数据块的数组，byte数据块可以转为字符串，数组可不行
            // bufferhelper也就是替你计算了bufLength而已 
            var chunkAll = Buffer.concat(arrBuf, bufLength);
            var content = iconv.decode(chunkAll, 'gb2312'); // utf-8 content
            // fs.writeFileSync('data',content)
            handleBody(content);
        });
    });
}

function loginForNew(theurl,thebody,callback) {
    var d = new Date();
    var options = { method: 'POST',
                    url: theurl,
                    headers: 
                    { 'authorization': 'Basic YWRtaW46N2M0YThkMDljYTM3NjJhZjYxZTU5NTIwOTQzZGMyNjQ5NGY4OTQxYg==',
                      // 'content-type': 'application/json',
                      'cache-control': 'no-cache',
                      'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36' },
                    body: thebody };
                    // console.log(options)
    request(options, (error, response, body) => {
        // console.log(error, body);
        if (!error) {            
            gCookie = response.headers['set-cookie'][0];
            // console.log(body,gCookie);
            callback && callback();
            // console.log(response)
        }

    })
}


function postForNew(theurl,thebody) {
    var d = new Date();
    var options = { method: 'POST',
                    url: theurl,
                    headers:
                    {
                        // 'postman-token': 'fba913cf-0c7a-304d-6f64-79340cdc9deb',
                        'cache-control': 'no-cache',
                        'origin': 'http://evil.com/',
                        // 'cookie': 'caipiao_uname=clientadmin;'+response.headers['set-cookie'][0],
                        'cookie': gCookie,
                        'accept-language': 'zh-CN,zh;q=0.8,en;q=0.6',
                        'accept-encoding': 'gzip, deflate, sdch',
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                        'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1',
                        'x-devtools-emulate-network-conditions-client-id': '8494093f-ec53-47db-bf82-d1f6ca273fca',
                        'upgrade-insecure-requests': '1'
                    },
                    body: thebody };
    request(options, (error, response, body) => {
        // console.log(error, body);
        if (!error) {            
           // console.log(body);
            // console.log(response)
        }

    })
}


function SpiderHlj11x5Zhenghao() {
    requestUrl('http://www.zhenghao.cn/888hlj115/openall.php', function(body) {
        var exp = `http://www.zhenghao.cn/888hlj115/conf/openday`;
        var ars = body.split(exp);
        if(ars.length <= 1) {
            console.log("undefined error in zhenghao");
            return;
        }
        var haf = ars[1].split('/')[1].split('.')[0];
        requestUrl('http://www.zhenghao.cn/888hlj115/conf/openday/' + haf + '.html',function(body) {
            var exp1 = 'color=green size=+1><b><img';
            var ars1 = body.split(exp1);
            var ars2 = body.split('<font color=red size=+1>');

            var kgt1 = ars2[1].split('<b>')[1].split('日')[0];
            var kgt = kgt1.replace(/-/g, "");
            var kgt = kgt.slice(2);

            var qh = ars1.length -1;

            var haf1 = ars1[qh].split("src=/images");

            var kjs = [];

            for (var i = 1; i < 6; i++) {
            // for (var i in ars) {
                var nums = haf1[i].split('/')[1].split('.')[0];
                kjs[i-1] = nums;
            }

            var time_stamp = new Date().getTime() / 1000;
            var data1 = JSON.stringify({
                 "numbers": [{
                     "name":"黑龙江11选5", "period":kgt + qh, "timestamp": time_stamp, "datafrom": 'zh', "numarray": kjs
                    }]
            });
            // console.log(data1);
            postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            
        })      
    })
}
