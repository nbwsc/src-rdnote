var request = require('request');
var gCookie;
var num = '1';


var logindata = JSON.stringify({
                "username": "admin",
                "password": "7c4a8d09ca3762af61e59520943dc26494f8941b"});

loginForNew('http://123.57.212.33:8000/caipiao/web/login',logindata,function(){
     setInterval(function () {
        var d = new Date().getHours();
        if (d < 3 || d > 9) {
            NewBSpiderMobWebK10('http://m.cqkl10.icaile.com/kaijiang/'+ num);
        }
     }, 15 * 1000)
});

setInterval(function() {    
    loginForNew('http://123.57.212.33:8000/caipiao/web/login',logindata);
}, 3600 * 1000)



function loginForNew(theurl,thebody,callback) {
    var d = new Date();
    var options = { method: 'POST',
                    url: theurl,
                    headers: 
                    { 'authorization': 'Basic YWRtaW46N2M0YThkMDljYTM3NjJhZjYxZTU5NTIwOTQzZGMyNjQ5NGY4OTQxYg==',
                      // 'content-type': 'application/json',
                      'cache-control': 'no-cache',
                      'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36' },
                    body: thebody };
                    // console.log(options)
    request(options, (error, response, body) => {
        // console.log(error, body);
        if (!error) {            
            gCookie = response.headers['set-cookie'][0];
            // console.log(body,gCookie);
            callback && callback();
            // console.log(response)
        }

    })
}


function postForNew(theurl,thebody) {
    var d = new Date();
    var options = { method: 'POST',
                    url: theurl,
                    headers:
                    {
                        // 'postman-token': 'fba913cf-0c7a-304d-6f64-79340cdc9deb',
                        'cache-control': 'no-cache',
                        'origin': 'http://evil.com/',
                        // 'cookie': 'caipiao_uname=clientadmin;'+response.headers['set-cookie'][0],
                        'cookie': gCookie,
                        'accept-language': 'zh-CN,zh;q=0.8,en;q=0.6',
                        'accept-encoding': 'gzip, deflate, sdch',
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                        'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1',
                        'x-devtools-emulate-network-conditions-client-id': '8494093f-ec53-47db-bf82-d1f6ca273fca',
                        'upgrade-insecure-requests': '1'
                    },
                    body: thebody };
    request(options, (error, response, body) => {
        // console.log(error, body);
        if (!error) {            
            // console.log(body);
            // console.log(response)
        }

    })
}




function NewBSpiderMobWebK10(url) {
    request(url, (error, response, body) => {
        if (!error) {
            var exp = `<tr>`;
            var ars = body.split(exp);
            // console.log(ars)
            for (var i = 2; i < ars.length; i++) {
                var haf = ars[i].split('<td>');

                var d = new Date();
                var kgtyear = d.getYear().toString().slice(1, 3);
                var kgtMonth = d.getMonth() +1;
                if(kgtMonth < 10){
                    kgtMonth = '0' + kgtMonth;
                }

                var kgt = kgtyear + kgtMonth + haf[1].slice(0, 2);
                var qh = haf[1].slice(2, 4);

                var nums = haf[2].split('<')[0];
                var kjs = nums.split(",")

                var time_stamp = new Date().getTime() / 1000;
                var data1 = JSON.stringify({
                     "numbers": [{
                         "name":"重庆快乐十分", "period":kgt + qh, "timestamp": time_stamp, "datafrom": 'mw', "numarray": kjs}]
                });
                // console.log(data1);
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}
