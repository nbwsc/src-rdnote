var request = require('request');
// var http = require("http"); //http request
// var cheerio = require('cheerio'); //xml parser*
// var iconv = require('iconv-lite'); //gbk convert*
var gCookie;


var logindata = JSON.stringify({
    "username": "admin",
    "password": "7c4a8d09ca3762af61e59520943dc26494f8941b"
});

loginForNew('http://123.57.212.33:8000/caipiao/web/login', logindata, function() {
    setInterval(function() {
        var d = new Date().getHours();

        //低频彩    
        if ((d >= 20 && d <= 22) || (d >= 8 && d <= 9)) {
            NewBSpiderOfficePl5('http://www.lottery.gov.cn/historykj/history.jspx?_ltype=plw', 1);
            NewBSpiderOfficeQxc('http://www.lottery.gov.cn/historykj/history.jspx?_ltype=qxc', 1);
            NewSpiderMobWeb('http://m.dlt.icaile.com/kaijiang/2', '大乐透');
            NewSpiderMobWeb('http://m.ssq.icaile.com/kaijiang/2', '双色球');
            NewSpiderMobWeb('http://m.3d.icaile.com/kaijiang/2', '3D');
            NewBSpider3DSjh('http://kjh.55128.cn/3d-shijihao-80.htm', 1);
        }
        if (d == 19 || d == 18) {
            NewBSpider3DSjh('http://kjh.55128.cn/3d-shijihao-80.htm', 2);
        }

    }, 15 * 1000)
});

setInterval(function() {
    loginForNew('http://123.57.212.33:8000/caipiao/web/login', logindata);
}, 3600 * 1000)



function loginForNew(theurl, thebody, callback) {
    var d = new Date();
    var options = {
        method: 'POST',
        url: theurl,
        headers: {
            'authorization': 'Basic YWRtaW46N2M0YThkMDljYTM3NjJhZjYxZTU5NTIwOTQzZGMyNjQ5NGY4OTQxYg==',
            // 'content-type': 'application/json',
            'cache-control': 'no-cache',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36'
        },
        body: thebody
    };
    // console.log(options)
    request(options, (error, response, body) => {
        // console.log(error, body);
        if (!error) {
            gCookie = response.headers['set-cookie'][0];
            // console.log(body,gCookie);
            callback && callback();
            // console.log(response)
        }

    })
}


function postForNew(theurl, thebody) {
    var d = new Date();
    var options = {
        method: 'POST',
        url: theurl,
        headers: {
            // 'postman-token': 'fba913cf-0c7a-304d-6f64-79340cdc9deb',
            'cache-control': 'no-cache',
            'origin': 'http://evil.com/',
            // 'cookie': 'caipiao_uname=clientadmin;'+response.headers['set-cookie'][0],
            'cookie': gCookie,
            'accept-language': 'zh-CN,zh;q=0.8,en;q=0.6',
            'accept-encoding': 'gzip, deflate, sdch',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1',
            'x-devtools-emulate-network-conditions-client-id': '8494093f-ec53-47db-bf82-d1f6ca273fca',
            'upgrade-insecure-requests': '1'
        },
        body: thebody
    };
    request(options, (error, response, body) => {
        // console.log(error, body);
        if (!error) {
            // console.log(body);
            // console.log(response)
        }

    })
}

//开奖号一位变成两位
function Kjs1Change2(str) {
    if (str.length == 1) {
        return '0' + str;
    } else {
        return str;
    }
}


function NewBSpiderOfficeQxc(url, num) {
    var exp1 = '<tbody>';
    var exp2 = '<tr>';
    var kjs = [];

    request(url, (error, response, body) => {
        if (!error) {
            var ars1 = body.split(exp1);
            // console.log(ars1)
            var ars2 = ars1[1].split(exp2);
            // console.log(ars2.length);
            for (var i = 1; i <= num; i++) {
                var kgtqh = '20' + ars2[i].split('>')[1].split('<')[0];
                // console.log(kgtqh);        
                var tmpkjs1 = ars2[i].split('>')[3].split('<')[0];
                var tmpkjs2 = tmpkjs1.split('');
                for (var j = 0; j < tmpkjs2.length; j++) {
                    kjs[j] = Kjs1Change2(tmpkjs2[j]);
                }

                var time_stamp = new Date().getTime() / 1000;
                var data1 = JSON.stringify({
                    "numbers": [{
                        "name": "七星彩",
                        "period": kgtqh,
                        "timestamp": time_stamp,
                        "datafrom": 'of',
                        "numarray": kjs
                    }]
                });
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}


function NewBSpiderOfficePl5(url, num) {
    var exp1 = '<tbody>';
    var exp2 = '<tr>';
    var kjs = [];

    request(url, (error, response, body) => {
        if (!error) {
            var ars1 = body.split(exp1);
            // console.log(ars1)
            var ars2 = ars1[1].split(exp2);
            // console.log(ars2.length);
            for (var i = 1; i <= num; i++) {
                var kgtqh = '20' + ars2[i].split('>')[1].split('<')[0];
                // console.log(kgtqh);        
                var tmpkjs1 = ars2[i].split('>')[3].split('<')[0];
                kjs = tmpkjs1.split(' ');


                var time_stamp = new Date().getTime() / 1000;
                var data1 = JSON.stringify({
                    "numbers": [{
                        "name": "排列3",
                        "period": kgtqh,
                        "timestamp": time_stamp,
                        "datafrom": 'of',
                        "sjh": "False",
                        "numarray": kjs
                    }]
                });
                // console.log(data1);
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}

function NewBSpider3DSjh(url, num) {
    request(url, (error, response, body) => {
        if (!error) {

            var exp1 = '<tbody>';
            var exp = '<tr';
            var exp2 = '<td>';
            var exp3 = '<span';

            var ars1 = body.split(exp1);
            // console.log(ars1[1])
            var ars = ars1[1].split(exp);
            // console.log(ars)

            for (i = 1; i <= num; i++) {
                var ars2 = ars[i].split(exp2);
                var kgtqh = ars2[1].slice(0, 7);
                // console.log(kgtqh);

                var tmpkjs1 = ars2[3].split(exp3);
                var tmpkjs2 = tmpkjs1[1].split('>')[1].split('<')[0];
                var kjs = tmpkjs2.split('，');

                var time_stamp = new Date().getTime() / 1000;
                var data1 = JSON.stringify({
                    "numbers": [{
                        "name": "3D",
                        "period": kgtqh,
                        "timestamp": time_stamp,
                        "datafrom": '55',
                        "sjh": "True",
                        "numarray": [kjs[0].toString(), kjs[1].toString(), kjs[2].toString()]
                    }]
                });
                // console.log(data1);
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}

function NewSpiderMobWeb(url, caizhong) {
    request(url, (error, response, body) => {
        if (!error) {
            var exp = `<tr>`;
            var ars = body.split(exp);

            for (var i = 2; i < ars.length; i++) {
                var haf = ars[i].split('<td>');

                var d = new Date();
                var kjs = [];
                var ballnum;
                var kgtqh;

                // console.log(port);
                if (caizhong == '大乐透') {
                    kgtqh = '20' + haf[1].slice(0, 5);
                    ballnum = 7;
                }
                if (caizhong == '排列3') {
                    kgtqh = '20' + haf[1].slice(0, 5);
                    ballnum = 5;
                }
                if (caizhong == '双色球') {
                    kgtqh = '20' + haf[1].slice(0, 5);
                    ballnum = 7;
                }
                if (caizhong == '3D') {
                    kgtqh = '20' + haf[1].slice(0, 5);
                    ballnum = 3;
                }

                var haf1 = haf[2].split('"ball');

                for (var j = 1; j <= ballnum; j++) {
                    kjs[j - 1] = haf1[j].split('">')[1].split('</')[0];
                }

                var time_stamp = d.getTime() / 1000;

                if (caizhong == '大乐透') {
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgtqh,
                            "timestamp": time_stamp,
                            "datafrom": 'mw',
                            "numarray": [kjs[0].toString(), kjs[1].toString(), kjs[2].toString(), kjs[3].toString(), kjs[4].toString(), kjs[5].toString(), kjs[6].toString()]
                        }]
                    });
                }
                if (caizhong == '排列3') {
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgtqh,
                            "timestamp": time_stamp,
                            "datafrom": 'mw',
                            "sjh": "False",
                            "numarray": [kjs[0].toString(), kjs[1].toString(), kjs[2].toString(), kjs[3].toString(), kjs[4].toString()]
                        }]
                    });
                }
                if (caizhong == '双色球') {
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgtqh,
                            "timestamp": time_stamp,
                            "datafrom": 'mw',
                            "numarray": [kjs[0].toString(), kjs[1].toString(), kjs[2].toString(), kjs[3].toString(), kjs[4].toString(), kjs[5].toString(), kjs[6].toString()]
                        }]
                    });
                }
                if (caizhong == '3D') {
                    var data1 = JSON.stringify({
                        "numbers": [{
                            "name": caizhong,
                            "period": kgtqh,
                            "timestamp": time_stamp,
                            "datafrom": 'mw',
                            "sjh": "False",
                            "numarray": [kjs[0].toString(), kjs[1].toString(), kjs[2].toString()]
                        }]
                    });
                }
                // console.log(data1)
                postForNew('http://123.57.212.33:8000/caipiao/web/lotterynum/add_multiple', data1);
            }
        }
    })
}