var request = require('request');


setInterval(function(){
    var dd = new Date()
    var d = dd.getHours();
    var tmstmp = dd.getHours().toString() + ':' +dd.getMinutes().toString() + ':' + dd.getSeconds().toString()

    if (d<24 && d >7) {
    //    console.log("*******************",tmstmp,"**************************");
        SpiderBjK3offical(1);
    }
}, 15*1000)

function SpiderBjK3offical(n){
    var url = 'http://www.bwlc.gov.cn/bulletin/prevqck3.html';

    if(n > 30) {
        n = 30;
    }

    request(url, (error, response, body) => {
        if (!error) {
            var exp = `<tr class=`;
            var ars = body.split(exp);

            if(ars.length <= 1){
                console.log("undefined exit",ars.length)
                return;
            }

            for(i=1;i<=n;i++){
                // console.log(ars[i]);
                // console.log(i);
                var haf = ars[i].split('<td');                
                var kgtqh = '150' + haf[1].split('>')[1].split('</')[0];
                var kgt = kgtqh.slice(0,6);
                var qh = kgtqh.slice(-2);
                var tmpkjs = haf[2].split('>')[1].split('</')[0];
                var kjs = tmpkjs.split(',');

                var theurl = 'http://123.57.138.66:8095/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=of' + '&Kj1=' + kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2];
                request(theurl,function(a,b,c){
			if(c& c!=="Insert Exit ")
                    console.log(8095,tmstmp,c,kgtqh,kjs);
                });
            } 
        }
    })
}
