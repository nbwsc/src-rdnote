var request = require('request');
var tmstmp;

setInterval(function () {
    var d = new Date()
    var dd = d.getHours();
    var ddd = d.getMinutes();
    tmstmp = dd.toString() + ':' +ddd.toString() + ':' + d.getSeconds().toString()
    var time_stamp = new Date().getTime() / 1000;

    if (dd<24 && dd >7) {
        // console.log("*******************",tmstmp,"**************************");
        //快乐十分杂源集合
        
        Spiderbj11x5official('http://www.bjlot.com/bj11s5/bj11s5data/lastdraw.xml?_=' + time_stamp.toString());

    }
}, 15 * 1000)




function Spiderbj11x5official(url) {
    // console.log(url);
    request(url, (error, response, body) => {
        // console.log(body)
        if (!error) {
            var exp1 = '<lastNo>';
            var ars1=body.split(exp1);
            // console.log(ars1);
            var kgt = ars1[1].slice(0,6);
            var qh = ars1[1].slice(6,8);

            var exp2 = 'lastRes';
            var ars2 = body.split(exp2);
            var tmpkjs=ars2[1].split('>')[1].split('<')[0];
            var kjs = tmpkjs.split('+');
            // console.log(kgt,qh,kjs)

            request('http://123.57.138.66:8088' + '/InsertKjInf?KGTime=' + kgt + '&Qh=' + qh + '&ServerIP=' + 'of' + '&Kj1=' +
                kjs[0] + '&Kj2=' + kjs[1] + '&Kj3=' + kjs[2] + '&Kj4=' + kjs[3] + '&Kj5=' + kjs[4], (err, resp, body1) => {
                if(body1 && body1 !== 'Insert Exit ') {
                    console.log(tmstmp,body1, kgt, qh)
                }
            })
        }
    })

}

